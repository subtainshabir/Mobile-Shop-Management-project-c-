﻿namespace shop_Management.All_User_Controls
{
    partial class cust_puchase
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cust_puchase));
            this.label1 = new System.Windows.Forms.Label();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.txt_mail = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2TextBox5 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_gender = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_company = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_model = new Guna.UI2.WinForms.Guna2ComboBox();
            this.tx_name = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_contact = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_ram = new System.Windows.Forms.Label();
            this.lbl_finger = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.lbl_front = new System.Windows.Forms.Label();
            this.lbl_rear = new System.Windows.Forms.Label();
            this.lbl_expandable = new System.Windows.Forms.Label();
            this.lbl_internal = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_address = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_imei = new Guna.UI2.WinForms.Guna2TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.btn_purchase = new Guna.UI2.WinForms.Guna2Button();
            this.guna2ShadowPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(18, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(433, 75);
            this.label1.TabIndex = 1;
            this.label1.Text = "Customer Purchase";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            this.guna2Elipse1.TargetControl = this;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 129);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name";
            // 
            // txt_mail
            // 
            this.txt_mail.BorderColor = System.Drawing.Color.Black;
            this.txt_mail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_mail.DefaultText = "";
            this.txt_mail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_mail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_mail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_mail.DisabledState.Parent = this.txt_mail;
            this.txt_mail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_mail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_mail.FocusedState.Parent = this.txt_mail;
            this.txt_mail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_mail.HoverState.Parent = this.txt_mail;
            this.txt_mail.Location = new System.Drawing.Point(26, 488);
            this.txt_mail.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.PasswordChar = '\0';
            this.txt_mail.PlaceholderText = "";
            this.txt_mail.SelectedText = "";
            this.txt_mail.ShadowDecoration.Parent = this.txt_mail;
            this.txt_mail.Size = new System.Drawing.Size(425, 42);
            this.txt_mail.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt_mail.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 238);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 339);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 32);
            this.label4.TabIndex = 2;
            this.label4.Text = "Contact No";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 448);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 32);
            this.label5.TabIndex = 2;
            this.label5.Text = "Email ID";
            // 
            // guna2TextBox5
            // 
            this.guna2TextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox5.DefaultText = "";
            this.guna2TextBox5.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.DisabledState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.FocusedState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.HoverState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.Location = new System.Drawing.Point(35, 1080);
            this.guna2TextBox5.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.guna2TextBox5.Name = "guna2TextBox5";
            this.guna2TextBox5.PasswordChar = '\0';
            this.guna2TextBox5.PlaceholderText = "";
            this.guna2TextBox5.SelectedText = "";
            this.guna2TextBox5.ShadowDecoration.Parent = this.guna2TextBox5;
            this.guna2TextBox5.Size = new System.Drawing.Size(567, 82);
            this.guna2TextBox5.TabIndex = 3;
            // 
            // txt_gender
            // 
            this.txt_gender.BackColor = System.Drawing.Color.Transparent;
            this.txt_gender.BorderColor = System.Drawing.Color.Black;
            this.txt_gender.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txt_gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_gender.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_gender.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_gender.FocusedState.Parent = this.txt_gender;
            this.txt_gender.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txt_gender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.txt_gender.HoverState.Parent = this.txt_gender;
            this.txt_gender.ItemHeight = 35;
            this.txt_gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.txt_gender.ItemsAppearance.Parent = this.txt_gender;
            this.txt_gender.Location = new System.Drawing.Point(26, 273);
            this.txt_gender.Name = "txt_gender";
            this.txt_gender.ShadowDecoration.Parent = this.txt_gender;
            this.txt_gender.Size = new System.Drawing.Size(425, 41);
            this.txt_gender.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt_gender.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(571, 129);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 32);
            this.label7.TabIndex = 2;
            this.label7.Text = "Company";
            // 
            // txt_company
            // 
            this.txt_company.BackColor = System.Drawing.Color.Transparent;
            this.txt_company.BorderColor = System.Drawing.Color.Black;
            this.txt_company.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txt_company.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_company.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_company.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_company.FocusedState.Parent = this.txt_company;
            this.txt_company.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txt_company.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.txt_company.HoverState.Parent = this.txt_company;
            this.txt_company.ItemHeight = 30;
            this.txt_company.ItemsAppearance.Parent = this.txt_company;
            this.txt_company.Location = new System.Drawing.Point(577, 169);
            this.txt_company.Name = "txt_company";
            this.txt_company.ShadowDecoration.Parent = this.txt_company;
            this.txt_company.Size = new System.Drawing.Size(425, 36);
            this.txt_company.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt_company.TabIndex = 4;
            this.txt_company.SelectedIndexChanged += new System.EventHandler(this.txt_company_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(571, 227);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 32);
            this.label8.TabIndex = 2;
            this.label8.Text = "Model";
            // 
            // txt_model
            // 
            this.txt_model.BackColor = System.Drawing.Color.Transparent;
            this.txt_model.BorderColor = System.Drawing.Color.Black;
            this.txt_model.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txt_model.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txt_model.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_model.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_model.FocusedState.Parent = this.txt_model;
            this.txt_model.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txt_model.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.txt_model.HoverState.Parent = this.txt_model;
            this.txt_model.ItemHeight = 30;
            this.txt_model.ItemsAppearance.Parent = this.txt_model;
            this.txt_model.Location = new System.Drawing.Point(577, 273);
            this.txt_model.Name = "txt_model";
            this.txt_model.ShadowDecoration.Parent = this.txt_model;
            this.txt_model.Size = new System.Drawing.Size(425, 36);
            this.txt_model.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt_model.TabIndex = 4;
            this.txt_model.SelectedIndexChanged += new System.EventHandler(this.txt_model_SelectedIndexChanged);
            // 
            // tx_name
            // 
            this.tx_name.BorderColor = System.Drawing.Color.Black;
            this.tx_name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tx_name.DefaultText = "";
            this.tx_name.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.tx_name.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.tx_name.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tx_name.DisabledState.Parent = this.tx_name;
            this.tx_name.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.tx_name.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tx_name.FocusedState.Parent = this.tx_name;
            this.tx_name.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.tx_name.HoverState.Parent = this.tx_name;
            this.tx_name.Location = new System.Drawing.Point(26, 169);
            this.tx_name.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.tx_name.Name = "tx_name";
            this.tx_name.PasswordChar = '\0';
            this.tx_name.PlaceholderText = "";
            this.tx_name.SelectedText = "";
            this.tx_name.ShadowDecoration.Parent = this.tx_name;
            this.tx_name.Size = new System.Drawing.Size(425, 42);
            this.tx_name.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.tx_name.TabIndex = 3;
            // 
            // txt_contact
            // 
            this.txt_contact.BorderColor = System.Drawing.Color.Black;
            this.txt_contact.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_contact.DefaultText = "";
            this.txt_contact.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_contact.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_contact.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_contact.DisabledState.Parent = this.txt_contact;
            this.txt_contact.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_contact.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_contact.FocusedState.Parent = this.txt_contact;
            this.txt_contact.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_contact.HoverState.Parent = this.txt_contact;
            this.txt_contact.Location = new System.Drawing.Point(26, 382);
            this.txt_contact.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.txt_contact.Name = "txt_contact";
            this.txt_contact.PasswordChar = '\0';
            this.txt_contact.PlaceholderText = "";
            this.txt_contact.SelectedText = "";
            this.txt_contact.ShadowDecoration.Parent = this.txt_contact;
            this.txt_contact.Size = new System.Drawing.Size(425, 44);
            this.txt_contact.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt_contact.TabIndex = 3;
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.label13);
            this.guna2ShadowPanel1.Controls.Add(this.label16);
            this.guna2ShadowPanel1.Controls.Add(this.label15);
            this.guna2ShadowPanel1.Controls.Add(this.label14);
            this.guna2ShadowPanel1.Controls.Add(this.label12);
            this.guna2ShadowPanel1.Controls.Add(this.lbl_ram);
            this.guna2ShadowPanel1.Controls.Add(this.lbl_finger);
            this.guna2ShadowPanel1.Controls.Add(this.lbl_price);
            this.guna2ShadowPanel1.Controls.Add(this.lbl_front);
            this.guna2ShadowPanel1.Controls.Add(this.lbl_rear);
            this.guna2ShadowPanel1.Controls.Add(this.lbl_expandable);
            this.guna2ShadowPanel1.Controls.Add(this.lbl_internal);
            this.guna2ShadowPanel1.Controls.Add(this.label11);
            this.guna2ShadowPanel1.Controls.Add(this.label10);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(577, 326);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(427, 296);
            this.guna2ShadowPanel1.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label13.Location = new System.Drawing.Point(57, 79);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(190, 25);
            this.label13.TabIndex = 8;
            this.label13.Text = "Expandable Storage";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label16.Location = new System.Drawing.Point(190, 206);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(140, 29);
            this.label16.TabIndex = 9;
            this.label16.Text = "Price (PKR)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label15.Location = new System.Drawing.Point(57, 162);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(174, 25);
            this.label15.TabIndex = 10;
            this.label15.Text = "FingerPrint Sensor";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label14.Location = new System.Drawing.Point(57, 132);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 25);
            this.label14.TabIndex = 11;
            this.label14.Text = "Front Camera";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label12.Location = new System.Drawing.Point(57, 106);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 25);
            this.label12.TabIndex = 12;
            this.label12.Text = "Rear Camera";
            // 
            // lbl_ram
            // 
            this.lbl_ram.AutoSize = true;
            this.lbl_ram.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_ram.Location = new System.Drawing.Point(168, 20);
            this.lbl_ram.Name = "lbl_ram";
            this.lbl_ram.Size = new System.Drawing.Size(54, 25);
            this.lbl_ram.TabIndex = 13;
            this.lbl_ram.Text = "------";
            // 
            // lbl_finger
            // 
            this.lbl_finger.AutoSize = true;
            this.lbl_finger.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_finger.Location = new System.Drawing.Point(253, 162);
            this.lbl_finger.Name = "lbl_finger";
            this.lbl_finger.Size = new System.Drawing.Size(54, 25);
            this.lbl_finger.TabIndex = 14;
            this.lbl_finger.Text = "------";
            // 
            // lbl_price
            // 
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_price.Location = new System.Drawing.Point(342, 206);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(54, 25);
            this.lbl_price.TabIndex = 15;
            this.lbl_price.Text = "------";
            this.lbl_price.Click += new System.EventHandler(this.label22_Click);
            // 
            // lbl_front
            // 
            this.lbl_front.AutoSize = true;
            this.lbl_front.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_front.Location = new System.Drawing.Point(253, 128);
            this.lbl_front.Name = "lbl_front";
            this.lbl_front.Size = new System.Drawing.Size(54, 25);
            this.lbl_front.TabIndex = 16;
            this.lbl_front.Text = "------";
            // 
            // lbl_rear
            // 
            this.lbl_rear.AutoSize = true;
            this.lbl_rear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_rear.Location = new System.Drawing.Point(253, 106);
            this.lbl_rear.Name = "lbl_rear";
            this.lbl_rear.Size = new System.Drawing.Size(54, 25);
            this.lbl_rear.TabIndex = 17;
            this.lbl_rear.Text = "------";
            // 
            // lbl_expandable
            // 
            this.lbl_expandable.AutoSize = true;
            this.lbl_expandable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_expandable.Location = new System.Drawing.Point(253, 75);
            this.lbl_expandable.Name = "lbl_expandable";
            this.lbl_expandable.Size = new System.Drawing.Size(54, 25);
            this.lbl_expandable.TabIndex = 18;
            this.lbl_expandable.Text = "------";
            // 
            // lbl_internal
            // 
            this.lbl_internal.AutoSize = true;
            this.lbl_internal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_internal.Location = new System.Drawing.Point(253, 50);
            this.lbl_internal.Name = "lbl_internal";
            this.lbl_internal.Size = new System.Drawing.Size(54, 25);
            this.lbl_internal.TabIndex = 19;
            this.lbl_internal.Text = "------";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label11.Location = new System.Drawing.Point(57, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 25);
            this.label11.TabIndex = 20;
            this.label11.Text = "RAM";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label10.Location = new System.Drawing.Point(57, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(150, 25);
            this.label10.TabIndex = 7;
            this.label10.Text = "Internal Storage";
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3.DefaultText = "";
            this.guna2TextBox3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.DisabledState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.FocusedState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.HoverState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Location = new System.Drawing.Point(26, 604);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.PasswordChar = '\0';
            this.guna2TextBox3.PlaceholderText = "";
            this.guna2TextBox3.SelectedText = "";
            this.guna2TextBox3.ShadowDecoration.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Size = new System.Drawing.Size(425, 44);
            this.guna2TextBox3.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.guna2TextBox3.TabIndex = 3;
            // 
            // txt_address
            // 
            this.txt_address.BorderColor = System.Drawing.Color.Black;
            this.txt_address.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_address.DefaultText = "";
            this.txt_address.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_address.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_address.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_address.DisabledState.Parent = this.txt_address;
            this.txt_address.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_address.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_address.FocusedState.Parent = this.txt_address;
            this.txt_address.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_address.HoverState.Parent = this.txt_address;
            this.txt_address.Location = new System.Drawing.Point(26, 604);
            this.txt_address.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.txt_address.Name = "txt_address";
            this.txt_address.PasswordChar = '\0';
            this.txt_address.PlaceholderText = "";
            this.txt_address.SelectedText = "";
            this.txt_address.ShadowDecoration.Parent = this.txt_address;
            this.txt_address.Size = new System.Drawing.Size(425, 44);
            this.txt_address.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt_address.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 551);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 32);
            this.label6.TabIndex = 2;
            this.label6.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 551);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 32);
            this.label9.TabIndex = 2;
            this.label9.Text = "Address";
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox4.DefaultText = "";
            this.guna2TextBox4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.DisabledState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.FocusedState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.HoverState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.Location = new System.Drawing.Point(26, 722);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.PasswordChar = '\0';
            this.guna2TextBox4.PlaceholderText = "";
            this.guna2TextBox4.SelectedText = "";
            this.guna2TextBox4.ShadowDecoration.Parent = this.guna2TextBox4;
            this.guna2TextBox4.Size = new System.Drawing.Size(425, 44);
            this.guna2TextBox4.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.guna2TextBox4.TabIndex = 3;
            // 
            // txt_imei
            // 
            this.txt_imei.BorderColor = System.Drawing.Color.Black;
            this.txt_imei.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_imei.DefaultText = "";
            this.txt_imei.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_imei.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_imei.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_imei.DisabledState.Parent = this.txt_imei;
            this.txt_imei.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_imei.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_imei.FocusedState.Parent = this.txt_imei;
            this.txt_imei.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_imei.HoverState.Parent = this.txt_imei;
            this.txt_imei.Location = new System.Drawing.Point(26, 722);
            this.txt_imei.Margin = new System.Windows.Forms.Padding(5, 8, 5, 8);
            this.txt_imei.Name = "txt_imei";
            this.txt_imei.PasswordChar = '\0';
            this.txt_imei.PlaceholderText = "";
            this.txt_imei.SelectedText = "";
            this.txt_imei.ShadowDecoration.Parent = this.txt_imei;
            this.txt_imei.Size = new System.Drawing.Size(425, 44);
            this.txt_imei.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txt_imei.TabIndex = 3;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(20, 669);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(118, 32);
            this.label24.TabIndex = 2;
            this.label24.Text = "Address";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(20, 669);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(177, 32);
            this.label25.TabIndex = 2;
            this.label25.Text = "IMEI Number";
            // 
            // btn_purchase
            // 
            this.btn_purchase.BorderRadius = 16;
            this.btn_purchase.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.btn_purchase.BorderThickness = 1;
            this.btn_purchase.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btn_purchase.CheckedState.FillColor = System.Drawing.Color.Black;
            this.btn_purchase.CheckedState.ForeColor = System.Drawing.Color.White;
            this.btn_purchase.CheckedState.Parent = this.btn_purchase;
            this.btn_purchase.CustomImages.Parent = this.btn_purchase;
            this.btn_purchase.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btn_purchase.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btn_purchase.ForeColor = System.Drawing.Color.Black;
            this.btn_purchase.HoverState.Parent = this.btn_purchase;
            this.btn_purchase.Image = ((System.Drawing.Image)(resources.GetObject("btn_purchase.Image")));
            this.btn_purchase.ImageSize = new System.Drawing.Size(30, 30);
            this.btn_purchase.Location = new System.Drawing.Point(718, 686);
            this.btn_purchase.Name = "btn_purchase";
            this.btn_purchase.ShadowDecoration.Parent = this.btn_purchase;
            this.btn_purchase.Size = new System.Drawing.Size(189, 45);
            this.btn_purchase.TabIndex = 8;
            this.btn_purchase.Text = "Purchase";
            this.btn_purchase.Click += new System.EventHandler(this.btn_purchase_Click);
            // 
            // cust_puchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btn_purchase);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Controls.Add(this.txt_model);
            this.Controls.Add(this.txt_company);
            this.Controls.Add(this.txt_gender);
            this.Controls.Add(this.guna2TextBox5);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_contact);
            this.Controls.Add(this.txt_imei);
            this.Controls.Add(this.guna2TextBox4);
            this.Controls.Add(this.txt_address);
            this.Controls.Add(this.guna2TextBox3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tx_name);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "cust_puchase";
            this.Size = new System.Drawing.Size(1029, 912);
            this.Load += new System.EventHandler(this.cust_puchase_Load);
            this.Enter += new System.EventHandler(this.cust_puchase_Enter);
            this.guna2ShadowPanel1.ResumeLayout(false);
            this.guna2ShadowPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txt_mail;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2ComboBox txt_model;
        private Guna.UI2.WinForms.Guna2ComboBox txt_company;
        private Guna.UI2.WinForms.Guna2ComboBox txt_gender;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox txt_contact;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox tx_name;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_ram;
        private System.Windows.Forms.Label lbl_finger;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Label lbl_front;
        private System.Windows.Forms.Label lbl_rear;
        private System.Windows.Forms.Label lbl_expandable;
        private System.Windows.Forms.Label lbl_internal;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2Button btn_purchase;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txt_imei;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4;
        private Guna.UI2.WinForms.Guna2TextBox txt_address;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
    }
}
